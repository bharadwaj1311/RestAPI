package com;

import java.net.URI;

import javax.ws.rs.core.MediaType;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;

public class RestClient {

	public static void main(String[] args) {
		try{
			final ClientConfig clientConfig = new DefaultClientConfig();
			final Client client = Client.create(clientConfig);
			final WebResource webResource = client.resource(URI.create("https://dev05-na03-joann.demandware.net/s/ditto/dw/shop/v19_1/content/tracking_hint?client_id=aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
			String contentData = webResource.accept(MediaType.APPLICATION_JSON).get(String.class);
			System.out.println("webResource"+contentData);
			
			
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

}
